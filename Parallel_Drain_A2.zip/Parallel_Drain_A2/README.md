# Assignment 2 – Parallel Drain (Group 3)

`Drain.py` is our Stage 1 sequential code and it is **not changed**.
`parallel_drain.py` splits the log file into chunks and runs `LogParser.parse()` from `Drain.py` on each chunk in a separate process (Python `multiprocessing`).

## Files

| File | What it is |
|---|---|
| `Drain.py` | Sequential Drain parser (same as Stage 1) |
| `run_benchmark.py`, `expand_dataset.py` | Stage 1 scripts (same as before) |
| `parallel_drain.py` | The parallel versions (one `--mode` per version) |
| `run_experiments.py` | Runs all experiments automatically and saves them to `results.csv` |

## The five versions (`--mode`)

| Mode | What it does | Result |
|---|---|---|
| `sequential` | 1 process. Also saves the correct result (`reference_<file>.json`) | Correct |
| `race` | N processes update shared data **without** synchronisation | **Wrong** (lost updates) |
| `critical` | One global `Lock` around every shared update (like `#pragma omp critical`) | Correct, slower |
| `atomic` | Each shared variable has its own lock (`Value.get_lock()` for the counter, like `#pragma omp atomic`) | Correct |
| `reduction` | No shared data. Every worker returns its own result and the main process merges them (like `reduction(+:...)`) | Correct, fastest |

## Shared resources (Task 1) – search for `RACE CONDITION` in `parallel_drain.py`

1. `lines_read` – global counter of processed lines. `+=` is read → add → write, so two processes can read the same old value and one increment is lost.
2. `template_counts` – global table {template: occurrences}. `counts[t] = counts.get(t, 0) + occ` is a read-modify-write: lost update.
3. `template_ids` + `next_id` – global EventId table. "if the template has no ID → take next_id → increase next_id" is check-then-act: duplicate or lost IDs.

## How to run (VS Code terminal, inside this folder)

```
python run_experiments.py --make-datasets
python parallel_drain.py --mode sequential --file HDFS_large.log
python parallel_drain.py --mode race       --file HDFS_large.log --workers 4
python parallel_drain.py --mode critical   --file HDFS_large.log --workers 4
python parallel_drain.py --mode atomic     --file HDFS_large.log --workers 4
python parallel_drain.py --mode reduction  --file HDFS_large.log --workers 4
```

- **Always run `sequential` first on each file**, because it saves the reference result that the other modes are checked against.
- Every run prints `Correct result: YES/NO`, the reason if it is wrong, and the execution time. It also adds a row to `results.csv`.
- To run everything automatically (3 runs each, 1/2/4/8 workers): `python run_experiments.py`
- Dataset sizes: `HDFS_light.log` = 1M lines, `HDFS_medium.log` = 4M lines, `HDFS_large.log` = 9M lines.

## Notes

- By default the "Processed x%" lines from Drain are hidden, so the times measure the parsing and not printing to the terminal. Add `--show-progress` to see them. Because of this, the Stage 1 times (measured with printing) are not directly comparable: **measure the new sequential baseline with `--mode sequential`**.
- The race version does not give the same wrong number every time. That is expected: it depends on how the processes are scheduled. Run it several times and record each result.
- Use at most as many workers as your CPU has cores (Task Manager → Performance → CPU → Cores).
