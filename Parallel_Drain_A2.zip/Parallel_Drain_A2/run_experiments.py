"""
Runs all Assignment 2 experiments one after another and appends every
result to results.csv (mode, workers, file, run, time, correct, ...).

  python run_experiments.py --make-datasets      # creates the light / medium files once
  python run_experiments.py                      # all modes, 1/2/4/8 workers, 3 runs, large file
  python run_experiments.py --files HDFS_light.log HDFS_medium.log HDFS_large.log
  python run_experiments.py --modes reduction critical --workers 2 4 --runs 3

The sequential run of each file is always done first, because it saves the
reference result that the parallel versions are checked against.
"""
import argparse
import os
import subprocess
import sys
from multiprocessing import cpu_count

SIZES = {"HDFS_light.log": 500, "HDFS_medium.log": 2000, "HDFS_large.log": 4500}  # x 2,000 lines


def make_datasets():
    with open("HDFS_2k.log", "r", encoding="utf-8") as f:
        content = f.read()
    for name, multiplier in SIZES.items():
        if os.path.exists(name):
            print(f"{name} already exists, skipped")
            continue
        print(f"Creating {name} ({2000 * multiplier:,} lines)...")
        with open(name, "w", encoding="utf-8") as f:
            for _ in range(multiplier):
                f.write(content)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--make-datasets", action="store_true")
    ap.add_argument("--files", nargs="+", default=["HDFS_large.log"])
    ap.add_argument("--modes", nargs="+",
                    default=["race", "critical", "atomic", "reduction"])
    ap.add_argument("--workers", nargs="+", type=int,
                    default=[w for w in (1, 2, 4, 8) if w <= cpu_count()])
    ap.add_argument("--runs", type=int, default=3)
    args = ap.parse_args()

    if args.make_datasets:
        make_datasets()
        return

    for file in args.files:
        jobs = [("sequential", 1)] + [(m, w) for m in args.modes for w in args.workers]
        for mode, workers in jobs:
            for run in range(1, args.runs + 1):
                print(f"\n>>> {file} | {mode} | {workers} workers | run {run}/{args.runs}")
                subprocess.run([sys.executable, "parallel_drain.py", "--mode", mode,
                                "--file", file, "--workers", str(workers),
                                "--run", str(run)], check=True)


if __name__ == "__main__":
    main()
