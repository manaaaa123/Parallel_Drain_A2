"""
ARTI 503 - Assignment 2: Parallel Code Experiments (Group 3)
Parallel version of the Drain log parser (Drain.py from LogPAI, modified by our group).

The Drain algorithm itself is NOT changed: every worker runs the same
LogParser.parse() from Drain.py on its own chunk of the log file.
This file only adds:
  1. splitting HDFS log files into chunks (one per worker process),
  2. shared data between the workers (to show race conditions),
  3. different synchronisation methods, and timing.

Modes:
  sequential : 1 process, no sharing (baseline, and it saves the reference result)
  race       : N processes, shared data updated WITHOUT any synchronisation
  critical   : N processes, one global Lock around every shared update (critical section)
  atomic     : N processes, each shared variable protected by its own lock
               (the counter uses Value.get_lock(), the table uses a separate lock)
  reduction  : N processes, NO shared data; every worker returns its local
               result and the main process merges them at the end

Usage examples:
  python parallel_drain.py --mode sequential --file HDFS_large.log
  python parallel_drain.py --mode race       --file HDFS_large.log --workers 4
  python parallel_drain.py --mode reduction  --file HDFS_large.log --workers 8
"""

import argparse
import contextlib
import csv
import io
import json
import os
import time
from multiprocessing import Lock, Manager, Pool, Value, cpu_count

from Drain import LogParser

# Same settings as run_benchmark.py
LOG_FORMAT = "<Date> <Time> <Pid> <Level> <Component>: <Content>"
REGEX = [r"blk_(|-)\d+", r"(\d+\.){3}\d+"]
DEPTH = 4
ST = 0.5


# ---------------------------------------------------------------------------
# Shared state (given to every worker process when the pool starts)
# ---------------------------------------------------------------------------
# SHARED RESOURCE 1: lines_read      -> global counter of processed lines
# SHARED RESOURCE 2: template_counts -> global table {template: occurrences}
# SHARED RESOURCE 3: template_ids    -> global table {template: EventId},
#                                       with next_id as the shared ID counter
G = {}


def init_worker(lines_read, next_id, template_counts, template_ids, big_lock, table_lock):
    G["lines_read"] = lines_read
    G["next_id"] = next_id
    G["template_counts"] = template_counts
    G["template_ids"] = template_ids
    G["big_lock"] = big_lock      # used by mode "critical"
    G["table_lock"] = table_lock  # used by mode "atomic"


# ---------------------------------------------------------------------------
# A LogParser that reads only one byte range (chunk) of the file
# ---------------------------------------------------------------------------
class ChunkLogParser(LogParser):
    def __init__(self, start, end, mode, **kwargs):
        super().__init__(**kwargs)
        self.start, self.end, self.mode = start, end, mode
        self.clusters = []

    def load_data(self):
        """Same work as Drain.log_to_dataframe(), but only for bytes [start, end)."""
        headers, regex = self.generate_logformat_regex(self.log_format)
        path = os.path.join(self.path, self.logName)
        with open(path, "rb") as f:
            f.seek(self.start)
            raw = f.read(self.end - self.start)
        log_messages = []
        linecount = 0
        for line in raw.decode("utf-8").splitlines():
            match = regex.search(line.strip())
            if match is None:
                continue
            message = {header: match.group(header) for header in headers}
            linecount += 1
            message["LineId"] = linecount
            log_messages.append(message)
            count_one_line(self.mode)          # <-- shared counter update
        self.df_log = log_messages

    def outputResult(self, logClustL):
        # Keep the clusters so the worker can report them
        self.clusters = logClustL


def count_one_line(mode):
    """Update SHARED RESOURCE 1 (the global line counter)."""
    if mode == "race":
        # RACE CONDITION: '+=' is read -> add -> write. Two processes can read
        # the same old value, and then one increment is lost.
        G["lines_read"].value += 1
    elif mode == "critical":
        with G["big_lock"]:
            G["lines_read"].value += 1
    elif mode == "atomic":
        with G["lines_read"].get_lock():
            G["lines_read"].value += 1
    # sequential / reduction: nothing shared, the line is counted locally


def publish_templates(local_counts, mode):
    """Merge this worker's templates into SHARED RESOURCES 2 and 3."""
    for template, occ in local_counts.items():
        if mode == "race":
            update_tables(template, occ)          # no protection at all
        elif mode == "critical":
            with G["big_lock"]:
                update_tables(template, occ)
        elif mode == "atomic":
            with G["table_lock"]:
                update_tables(template, occ)


def update_tables(template, occ):
    counts, ids, next_id = G["template_counts"], G["template_ids"], G["next_id"]
    # RACE CONDITION (lost update): read the old count, add, write back.
    counts[template] = counts.get(template, 0) + occ
    # RACE CONDITION (check-then-act): two processes can both see that the
    # template has no ID yet, so the same template gets two different IDs
    # (or two templates get the same ID).
    if template not in ids:
        new_id = next_id.value
        next_id.value = new_id + 1
        ids[template] = new_id


# ---------------------------------------------------------------------------
# Work done by one worker process
# ---------------------------------------------------------------------------
def parse_chunk(task):
    file_path, start, end, mode, quiet = task
    parser = ChunkLogParser(
        start, end, mode,
        log_format=LOG_FORMAT, indir=os.path.dirname(file_path) or ".",
        outdir="./result/", depth=DEPTH, st=ST, rex=REGEX,
    )
    out = io.StringIO() if quiet else None
    with contextlib.redirect_stdout(out) if quiet else contextlib.nullcontext():
        parser.parse(os.path.basename(file_path))   # <-- Drain.py, unchanged

    local_counts = {}
    for c in parser.clusters:
        t = " ".join(c.logTemplate)
        local_counts[t] = local_counts.get(t, 0) + len(c.logIDL)
    local_lines = len(parser.df_log)

    if mode in ("race", "critical", "atomic"):
        publish_templates(local_counts, mode)
    # reduction: return local results, the main process merges them
    return local_lines, local_counts


# ---------------------------------------------------------------------------
# Splitting the file into chunks that start and end on line boundaries
# ---------------------------------------------------------------------------
def split_file(path, n_chunks):
    size = os.path.getsize(path)
    bounds = [0]
    with open(path, "rb") as f:
        for i in range(1, n_chunks):
            f.seek(size * i // n_chunks)
            f.readline()                      # move to the start of the next line
            bounds.append(f.tell())
    bounds.append(size)
    return [(bounds[i], bounds[i + 1]) for i in range(n_chunks) if bounds[i] < bounds[i + 1]]


def count_lines(path):
    n = 0
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 24), b""):
            n += block.count(b"\n")
    return n


# ---------------------------------------------------------------------------
# Run one experiment
# ---------------------------------------------------------------------------
def run(mode, file_path, workers, quiet):
    workers = 1 if mode == "sequential" else workers
    chunks = split_file(file_path, workers)
    tasks = [(file_path, s, e, mode, quiet) for s, e in chunks]

    manager = Manager()
    lines_read = Value("q", 0)
    next_id = Value("q", 0)
    template_counts = manager.dict()
    template_ids = manager.dict()
    big_lock, table_lock = Lock(), Lock()
    init_args = (lines_read, next_id, template_counts, template_ids, big_lock, table_lock)

    t0 = time.perf_counter()
    if mode == "sequential":
        init_worker(*init_args)
        results = [parse_chunk(tasks[0])]
    else:
        with Pool(processes=workers, initializer=init_worker, initargs=init_args) as pool:
            results = pool.map(parse_chunk, tasks)

    if mode in ("sequential", "reduction"):
        # REDUCTION: combine the private results of every worker
        total_lines = sum(r[0] for r in results)
        counts = {}
        for _, local_counts in results:
            for t, occ in local_counts.items():
                counts[t] = counts.get(t, 0) + occ
        ids = {t: i for i, t in enumerate(counts)}
    else:
        total_lines = lines_read.value
        counts = dict(template_counts)
        ids = dict(template_ids)
    elapsed = time.perf_counter() - t0
    manager.shutdown()
    return elapsed, total_lines, counts, ids


def check(mode, file_path, total_lines, counts, ids):
    """Compare with the sequential reference result of the same file."""
    expected_lines = count_lines(file_path)
    ref_path = "reference_" + os.path.basename(file_path) + ".json"
    if mode == "sequential":
        with open(ref_path, "w", encoding="utf-8") as f:
            json.dump(counts, f, indent=1)
    ref = None
    if os.path.exists(ref_path):
        with open(ref_path, encoding="utf-8") as f:
            ref = json.load(f)

    problems = []
    if total_lines != expected_lines:
        problems.append(f"lines counted {total_lines:,} instead of {expected_lines:,}")
    occ_sum = sum(counts.values())
    if occ_sum != expected_lines:
        problems.append(f"template occurrences add up to {occ_sum:,} instead of {expected_lines:,}")
    if len(set(ids.values())) != len(ids) or len(ids) != len(counts):
        problems.append(f"EventIds are not unique ({len(ids)} templates, {len(set(ids.values()))} distinct IDs)")
    if ref is None:
        problems.append("no reference yet: run --mode sequential on this file first")
    elif counts != ref:
        problems.append("templates/counts differ from the sequential result")
    return expected_lines, problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", required=True,
                    choices=["sequential", "race", "critical", "atomic", "reduction"])
    ap.add_argument("--file", default="HDFS_large.log")
    ap.add_argument("--workers", type=int, default=cpu_count())
    ap.add_argument("--run", type=int, default=1, help="run number, only written to the CSV")
    ap.add_argument("--show-progress", action="store_true",
                    help="print Drain's 'Processed x%%' lines (slower)")
    args = ap.parse_args()

    elapsed, total_lines, counts, ids = run(args.mode, args.file, args.workers,
                                             quiet=not args.show_progress)
    expected, problems = check(args.mode, args.file, total_lines, counts, ids)
    workers = 1 if args.mode == "sequential" else args.workers
    correct = not problems

    print("--------------------------------------------------")
    print(f"Mode: {args.mode} | workers: {workers} | file: {args.file}")
    print(f"Lines counted: {total_lines:,} / {expected:,} | templates: {len(counts)}")
    print("Correct result: " + ("YES" if correct else "NO"))
    for p in problems:
        print("  - " + p)
    print(f"Execution time: {elapsed:.2f} s")
    print("--------------------------------------------------")

    new = not os.path.exists("results.csv")
    with open("results.csv", "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["mode", "workers", "file", "run", "time_s", "correct",
                        "lines_counted", "expected_lines", "templates", "problems"])
        w.writerow([args.mode, workers, args.file, args.run, f"{elapsed:.3f}", correct,
                    total_lines, expected, len(counts), "; ".join(problems)])


if __name__ == "__main__":
    main()
